# 🚀 Sistema de Predicción ML con Docker

Aplicación completa de Machine Learning con frontend (Streamlit) y backend (FastAPI) contenerizada con Docker.

## 📋 Tabla de Contenidos
- [Características](#características)
- [Requisitos](#requisitos)
- [Instalación Rápida](#instalación-rápida)
- [Desarrollo Local](#desarrollo-local)
- [Despliegue en la Nube](#despliegue-en-la-nube)
- [API Documentation](#api-documentation)

## ✨ Características
- **Backend**: FastAPI con endpoints REST para predicciones
- **Frontend**: Dashboard interactivo con Streamlit
- **Containerización**: Docker y Docker Compose
- **Escalable**: Soporte para predicciones individuales y batch
- **Documentación**: Swagger UI y ReDoc

## 🔧 Requisitos
- Docker 20.10+
- Docker Compose 2.0+
- Git
- Python 3.10 (para desarrollo local)

## 🚀 Instalación Rápida

### 1. Clonar el repositorio
```bash
git clone https://github.com/PonchitoSalcedo/docker-ml-app.git
cd docker-ml-app
```

### 2. Ejecutar con Docker Compose
```bash
docker-compose up --build
```

### 3. Acceder a la aplicación
- Frontend: http://localhost:8501
- Backend API: http://localhost:8000
- API Docs: http://localhost:8000/docs

## 📊 API Documentation

### Endpoints Disponibles
| Método | Endpoint | Descripción |
|--------|----------|-------------|
| GET | `/` | Información de la API |
| GET | `/health` | Health check del servicio |
| POST | `/predict` | Predicción individual |
| POST | `/batch_predict` | Predicción en lote |

### Ejemplo de Uso
```python
import requests

data = {
    "feature1": 25.5,
    "feature2": 30.2,
    "feature3": 45.8,
    "feature4": 12.3
}
response = requests.post("http://localhost:8000/predict", json=data)
print(response.json())
```

## ☁️ Despliegue en la Nube

### Google Cloud Run
```bash
gcloud builds submit --tag gcr.io/PROJECT_ID/ml-app
gcloud run deploy ml-app --image gcr.io/PROJECT_ID/ml-app --platform managed
```

## 📄 Licencia
MIT License

## 📧 Contacto
- **Autor**: Tu Nombre
- **GitHub**: [@PonchitoSalcedo](https://github.com/PonchitoSalcedo)
